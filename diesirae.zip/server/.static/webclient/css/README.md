You can replace the CSS files for Evennia's webclient here.

You can find the original files in `evennia/web/static/webclient/css/`
