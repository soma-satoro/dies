You can replace the image files for Evennia's home page here.

You can find the original files in `evennia/web/static/website/images/`
